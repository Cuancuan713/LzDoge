<?php

// ISI DATA //

$cookie="xxx";

$useragent="xxx";


//## ISI WAKTU WITHDRAW SESUAI KE INGINAN ANDA ##
//## MINIMAL 70 SECOND :)

$second="70";
